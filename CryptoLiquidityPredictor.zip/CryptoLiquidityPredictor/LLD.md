## Low-Level Design (LLD): Cryptocurrency Liquidity Prediction System

---

### 📂 Module 1: Data Collection

- **Input**: Two CSV files (from CoinGecko)
- **Processing**:
  - Load using `pd.read_csv()`
  - Concatenate with `pd.concat()`
  - Convert `date` column to `datetime`
- **Output**: Single cleaned DataFrame

---

### 🧹 Module 2: Data Preprocessing

- Convert string columns to numeric (`price`, `volume`, `market cap`, etc.)
- Handle missing values with `dropna()`
- Standardize or normalize if required (optional)

---

### ⚙️ Module 3: Feature Engineering

| Feature             | Formula / Logic                                             |
|---------------------|-------------------------------------------------------------|
| `volume_to_mcap`    | `24h_volume / mkt_cap`                                      |
| `price_volatility`  | `std([1h, 24h, 7d])`                                        |
| `bullishness`       | Count of positive % changes among 1h, 24h, 7d               |
| `price_normalized`  | `price / first_price_in_group(symbol)`                     |
| `liquidity_label`   | Binary label (1 if `volume_to_mcap` > median, else 0)       |

---

### 🤖 Module 4: Model Building

- Algorithm: `RandomForestClassifier`
- Features used:
  - `price`, `volume_to_mcap`, `price_volatility`, `bullishness`, `price_normalized`
- Target: `liquidity_label`
- Split: `train_test_split()`

---

### 🧪 Module 5: Evaluation

- Metrics: `accuracy_score`, `confusion_matrix`, `classification_report`
- Feature Importance: `model.feature_importances_`

---

### 🚀 Module 6: Deployment

- Framework: `Streamlit`
- Components:
  - Input fields (`st.number_input`, `st.slider`)
  - Load model using `joblib.load()`
  - Prediction displayed using `st.success()`

---

### 🔄 Flow Summary:

```plaintext
CSV Files ➝ Preprocessing ➝ Feature Engineering ➝ Model Training ➝ Evaluation ➝ Streamlit App
