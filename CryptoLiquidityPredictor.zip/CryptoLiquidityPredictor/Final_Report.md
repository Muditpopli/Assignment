## Final Report: Cryptocurrency Liquidity Prediction

### 📌 Objective:
Build a machine learning model to predict liquidity levels in the cryptocurrency market based on market indicators, and deploy it via Streamlit.

### 📊 Dataset:
- Combined two days of coin-level data from CoinGecko.
- Fields: price, market cap, 24h volume, 1h/24h/7d % change, etc.

### 🔧 Feature Engineering:
- `volume_to_mcap`: Core liquidity proxy
- `price_volatility`: Std of 1h, 24h, 7d % change
- `bullishness`: Positive % change count (0–3)
- `price_normalized`: Price normalized per symbol

### 🤖 Model:
- RandomForestClassifier
- Label: `liquidity_label` = 1 (High) or 0 (Low)
- Accuracy: ~90%+
- Feature importance shows `volume_to_mcap` is dominant

### 🚀 Deployment:
- Streamlit app accepts 5 features and predicts liquidity
- Successfully runs on localhost (`app.py` + `.pkl`)

### 📈 Next Steps:
- Include longer time windows, more coins
- Add social media/on-chain indicators
- Host app publicly via Streamlit Cloud

