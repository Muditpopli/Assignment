## High-Level Design (HLD): Cryptocurrency Liquidity Prediction

### 🔶 System Overview:
The system is designed to predict cryptocurrency liquidity using market-level features and classify it into High or Low liquidity categories. It helps detect potential market instability and is deployed using Streamlit for real-time interaction.

---

### 🔷 System Components:

1. **Data Source**
   - CoinGecko CSV files containing historical market data
   - Includes price, volume, market cap, and % changes (1h, 24h, 7d)

2. **Data Preprocessing**
   - Data concatenation and cleaning
   - Handling missing values and formatting columns

3. **Feature Engineering**
   - Derived features:
     - `volume_to_mcap`
     - `price_volatility`
     - `bullishness`
     - `price_normalized`

4. **Model Training**
   - Model: Random Forest Classifier
   - Target: `liquidity_label`
   - Hyperparameter tuning using GridSearchCV

5. **Model Evaluation**
   - Accuracy, Confusion Matrix, Classification Report
   - Feature Importance Analysis

6. **Deployment**
   - Web app using Streamlit
   - Takes user inputs and displays predicted liquidity level

---

### 🛠 Tools & Technologies:
- Python
- Pandas, scikit-learn, Matplotlib, Seaborn
- Streamlit (for deployment)
