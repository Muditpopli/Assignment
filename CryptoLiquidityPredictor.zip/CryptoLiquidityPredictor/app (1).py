
import streamlit as st
import pandas as pd
import joblib

# Load model
model = joblib.load("liquidity_predictor.pkl")

st.title("Cryptocurrency Liquidity Predictor")

# Inputs
price = st.number_input("Price")
volume_to_mcap = st.number_input("Volume to Market Cap Ratio")
price_volatility = st.number_input("Price Volatility")
bullishness = st.slider("Bullishness Score (0 to 3)", 0, 3, 1)
price_normalized = st.number_input("Normalized Price")

# Predict
input_df = pd.DataFrame([[price, volume_to_mcap, price_volatility, bullishness, price_normalized]],
                        columns=['price', 'volume_to_mcap', 'price_volatility', 'bullishness', 'price_normalized'])

if st.button("Predict Liquidity Level"):
    prediction = model.predict(input_df)[0]
    st.success(f"Predicted Liquidity: {'High' if prediction == 1 else 'Low'}")
