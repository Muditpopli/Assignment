## Pipeline Architecture: Cryptocurrency Liquidity Prediction System

---

### 🧱 Architecture Overview:

The pipeline follows a modular structure from data collection to user-facing deployment. Each stage builds on the previous and is designed to be scalable and modular.

---

### 🔗 Data Flow Diagram:

```plaintext
+--------------------+
|  CSV Input Files   |  ←─ coin_gecko_*.csv
+--------------------+
          |
          v
+--------------------+
| Data Preprocessing |  ←─ Clean, Convert, Handle Missing
+--------------------+
          |
          v
+----------------------+
| Feature Engineering  |  ←─ Derive volume_to_mcap, etc.
+----------------------+
          |
          v
+------------------+         +----------------+
|   Train/Test     | <────── |  Target Label  |
|    Split         |         | liquidity_label|
+------------------+         +----------------+
          |
          v
+----------------------+
|  Model Training (RF) |
+----------------------+
          |
          v
+-------------------------+
|   Model Evaluation      |
|   Accuracy, F1, Report  |
+-------------------------+
          |
          v
+-----------------------------+
|   Streamlit Deployment App |
+-----------------------------+
